
===========================================================
==== Visual Library 2.0 - version pre3

This is a distribution of the NetBeans Visual Library project.

For information look at the home page:
http://graph.netbeans.org

This is a development build - USE IT AT YOUR OWN RISK.

===========================================================
==== Directories:

dist/ - binary distribution
    org-openide-util.jar - the library dependency
    org-netbeans-api-visual.jar - the library
    org-netbeans-modules-visual-examples.jar - the library examples

doc/ - documentation
    documentation.html
    faq.html

javadoc/
    org-openide-util - the javadoc of openide-util package
    org-netbeans-api-visual - the javadoc of the library

sources/ - contains just the library sources
           you have to download NetBeans Platform sources too
    graph/ - the library module sources
             copy this directory into the NetBeans Platform sources directory
	