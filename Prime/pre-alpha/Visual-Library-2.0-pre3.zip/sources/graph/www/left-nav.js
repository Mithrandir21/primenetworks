document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectEdit">Administration</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectDownloadList">Project Files</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectIssues">Issue Tracking</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectMailingListList">Mailing Lists</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectMemberList">Members</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/servlets/ProjectNewsList">News</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/source/browse/graph/">Browse Source</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/setup.html">Setup</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/documentation.html">Documentation</a></div>');
document.write('  </div>');
document.write('  <div class="leftmenug">');
document.write('    <div class="leftmenuitem"><a href="/faq.html">FAQ</a></div>');
document.write('  </div>');

// document.write('<script src=local-left-nav.js type=text/javascript></script>');
// Uncomment the line above to include a per-directory navigation file, for 'dynamic' left navigation.
// See http://www.netbeans.org/community/guidelines/module-navigation.html for more info.
